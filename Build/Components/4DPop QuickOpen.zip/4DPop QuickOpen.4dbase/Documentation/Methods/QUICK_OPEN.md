<!-- QUICK_OPEN() -->
## Description
`QUICK_OPEN` display the quick open dialog

## Usage

Call `QUICK_OPEN` from your code. For example, a button.
